# @jodybrewster/gemini-live

A framework-free Gemini Live client for the browser, plus a token handler for the server.
It is the monorepo's `@gemini-live/core`, `audio`, `session` and `video` packages bundled into one ESM package with no workspace dependencies.
No React, no router, no env reads.

- `@jodybrewster/gemini-live` - browser-safe: `GeminiLiveSession`, `createFunctionTool`, `ResponseType` and the types a host needs.
- `@jodybrewster/gemini-live/server` - `createGeminiTokenHandler`, which mints short-lived Live API tokens with `@google/genai`. Only this entry imports `@google/genai`.

The audio worklets are embedded in the bundle and loaded from Blob URLs, so there are no files to copy into `public/`.

## Install

The package lives on GitHub Packages. Add an `.npmrc` next to your `package.json`:

```ini
@jodybrewster:registry=https://npm.pkg.github.com
//npm.pkg.github.com/:_authToken=${NPM_TOKEN}
```

`NPM_TOKEN` is a GitHub token with `read:packages`. Then:

```bash
npm install @jodybrewster/gemini-live
```

To try a local build without publishing, pack it here and install the tarball by path:

```bash
npm -w @jodybrewster/gemini-live run build
cd packages/gemini-live-bundle && npm pack
# in the host
npm install /path/to/gemini-live-nextjs/packages/gemini-live-bundle/jodybrewster-gemini-live-0.1.0.tgz
```

## Server: token endpoint

Any runtime with the Web `Response` API works (Astro endpoints, Next route handlers, Workers).

```ts
// src/pages/api/voice/token.ts (Astro)
import { createGeminiTokenHandler } from "@jodybrewster/gemini-live/server";

export const prerender = false;
export const POST = createGeminiTokenHandler({
  apiKey: import.meta.env.GEMINI_API_KEY,
  uses: 1,
  tokenExpiryMinutes: 10,
  sessionExpiryMinutes: 1,
  // Optional: lock the token to one model and config.
  liveConnectConstraints: { model: "gemini-3.8-live" },
});
```

`liveConnectConstraints` is passed straight to `authTokens.create`.
With it set, the whole Live setup is locked to the token's config, and whatever the browser sends in its own setup message (activity detection, tools, prompt) is ignored, so put the full config there.
Leave `lockAdditionalFields` unset unless you need it: Google rejects `lockAdditionalFields: []` with a 400 when the constrained config contains `tools`.

## Browser: a minimal voice button

```ts
import {
  GeminiLiveSession,
  createFunctionTool,
  type GeminiLiveConfig,
} from "@jodybrewster/gemini-live";

const session = new GeminiLiveSession({
  tokenEndpoint: "/api/voice/token",
  maxSessionMs: 5 * 60_000, // disconnects itself at the cap
  systemMessages: false, // keep "Ready!" / "[Microphone on]" out of the transcript
});

const openNote = createFunctionTool(
  "open_note",
  "Look up one of my notes by slug.",
  { slug: { type: "string" } },
  ["slug"],
  async ({ slug }) => {
    const res = await fetch(`/notes/${slug}.json`);
    return res.ok ? res.json() : null; // null: nothing to render in the chat
  },
);

const config: GeminiLiveConfig = {
  model: "gemini-3.8-live",
  systemInstructions: "You are a helpful assistant.",
  voiceName: "Puck",
  temperature: 1,
  googleGrounding: false,
  inputAudioTranscription: true,
  outputAudioTranscription: true,
  activityHandling: "ACTIVITY_HANDLING_UNSPECIFIED",
  automaticActivityDetection: {
    disabled: false,
    silence_duration_ms: 500,
    prefix_padding_ms: 500,
    end_of_speech_sensitivity: "END_SENSITIVITY_UNSPECIFIED",
    start_of_speech_sensitivity: "START_SENSITIVITY_UNSPECIFIED",
  },
  functions: [openNote],
};

session.subscribe(() => {
  const snap = session.getSnapshot();
  // Render from the snapshot: snap.connectionStatus, snap.messages,
  // snap.media.audio.isStreaming, snap.endsAt (countdown), snap.endReason.
});

button.addEventListener("click", async () => {
  if (session.getSnapshot().isConnected) {
    session.disconnect();
    return;
  }
  session.unlockAudio(); // synchronous, before any await
  try {
    await session.connect(config); // resolves on setup complete
    await session.toggleAudio(); // mic on
  } catch (error) {
    // connect() rejected: early close, socket error or 15 s timeout.
    // session.getSnapshot().lastError has the message.
  }
});
```

## API

`new GeminiLiveSession(options?)`

| Option | Default | |
|---|---|---|
| `tokenEndpoint` | `"/api/token"` | POST endpoint returning `{ token }`. |
| `maxSessionMs` | none | Caps a session, counted from setup complete. Ends with `endReason: "limit"`. |
| `connectTimeoutMs` | `15000` | How long `connect()` waits for setup complete. |
| `systemMessages` | `true` | Whether the session adds its own `system` messages to `messages`. |

Methods:

- `connect(config: GeminiLiveConfig): Promise<void>` - fetches a token, opens the socket and resolves once the server's setup complete arrives. Rejects if the socket closes or errors first, on timeout, or if `disconnect()` or another `connect()` supersedes it.
- `disconnect(): void` - ends the session with `endReason: "user"`.
- `unlockAudio(): void` - creates and resumes the playback AudioContext synchronously. Call it in the click handler before any `await`; iOS Safari leaves a context created later suspended.
- `toggleAudio(deviceId?: string): Promise<void>` - mic on/off.
- `toggleVideo(options?)`, `toggleScreen(options?)` - camera and screen share.
- `sendTextMessage(text: string): void`
- `subscribe(listener: () => void): () => void` and `getSnapshot(): SessionSnapshot` - a `useSyncExternalStore`-shaped store. The snapshot is a new object on every change.

`SessionSnapshot`:

```ts
{
  client: GeminiLiveAPI | null;
  isConnected: boolean;
  connectionStatus: "disconnected" | "connecting" | "connected" | "error";
  messages: ChatMessage[];
  audioPlayer: AudioPlayer | null;
  debugInfo: string;
  setupJson: string;
  endReason: "user" | "limit" | "goAway" | "closed" | "error" | null;
  endsAt: number | null; // epoch ms, set while maxSessionMs is running
  lastError: string | null;
  media: {
    audio: { isStreaming: boolean };
    video: { isStreaming: boolean; videoElement: HTMLVideoElement | null };
    screen: { isSharing: boolean; videoElement: HTMLVideoElement | null };
  };
}
```

Tools:

- `createFunctionTool(name, description, parameters, requiredParameters, fn, options?)` - `fn` may be async. `options.render` (default true) controls the chat message.
- Every local call in one toolCall batch is awaited, then answered with a single `toolResponse`. A rejected tool answers `{ error: message }` for its call only.
- `render: false` never adds a chat message. Otherwise an async tool's `tool-ui` message is added when it resolves, with the result as `toolData`; resolving to `null`/`undefined` adds nothing.

A Live API `goAway` from the server ends the session right away with `endReason: "goAway"`. Session resumption is not implemented.

## Gotchas

- The worklets load from `blob:` URLs. A Content-Security-Policy has to allow `blob:` for scripts (or `worker-src`, depending on the browser).
- Import `./server` only from server code. The root entry never reaches `@google/genai`.
- `connect()` rejects on failure. Catch it; with `systemMessages: false` nothing else tells the user.
