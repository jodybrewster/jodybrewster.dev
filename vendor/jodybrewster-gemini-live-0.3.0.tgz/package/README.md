# @jodybrewster/gemini-live

A framework-free Gemini Live client for the browser, plus a token handler for the server.
It is the monorepo's `@gemini-live/core`, `audio`, `session` and `video` packages bundled into one ESM package with no workspace dependencies.
No React, no router, no env reads.

- `@jodybrewster/gemini-live/core` - the text-only browser core, with no voice code: the message catalog, `disclosure()` and `fetchOrchestratorDisclosure`, the accessibility helpers (`createAnnouncer`, `createStreamAnnouncer`, `scheduleTimeWarnings`) and `readSseFrames`. `disclosure()` returns plain text: render it as text, never with `innerHTML` or `set:html`, since part of it can come from an orchestrator.
- `@jodybrewster/gemini-live/voice` - the voice session: `GeminiLiveSession`, the Gemini Live client, `createFunctionTool`, `AudioPlayer` and their types, plus `PLAYBACK_WORKLET_SOURCE` and `CAPTURE_WORKLET_SOURCE` for hosts whose security policy refuses `blob:` worklets (serve them from your origin and pass the URLs as the session's `audioWorklets`).
- `@jodybrewster/gemini-live` - the root re-exports `./voice` unchanged, so existing hosts keep working; new hosts should import `./core` or `./voice`.
- `@jodybrewster/gemini-live/server` - `createVoiceTokenHandler` and `voiceTokenRouteFromEnv`, which mint locked, short-lived Live API tokens behind an origin check and daily caps (see `@gemini-live/core`'s README). `createGeminiTokenHandler` was removed in 0.2.0 (it minted unlocked tokens for any caller).
- `@jodybrewster/gemini-live/server/limits` - the shared limiter (`createLimiter`, `createUpstashStore`, `limitStoreFromEnv`, `clientIp`, `limitResponse`, token budgets); see `@gemini-live/server-core`'s README.
- `@jodybrewster/gemini-live/server/switches` - kill switches (`createSwitches`, `enabledTools`); with no store they come from `SWITCH_*` env values alone.
- `@jodybrewster/gemini-live/server/audit` - the tamper-evident audit chain and its Upstash store (`chainKeyFromEnv`, `createUpstashAuditStore`, `verifyUpstashAudit`, `createLogAuditSink`, `createDenyThrottle`).
- `@jodybrewster/gemini-live/server/headers` - the security headers preset for a host's `astro.config` or header config (`astroCspDirectives`, `astroScriptResources`, `vercelHeaders`, `contentSecurityPolicy`, `staticSecurityHeaders`).

Peers are all optional and loaded only where used: `@google/genai` (`^1 || ^2`) by the token handler, `@upstash/redis` by the Upstash stores, `rate-limiter-flexible` by the memory limit store on first use. Install the ones your server code needs; the token handler uses your copy of `@google/genai`, never a nested one.

The audio worklets are embedded in the bundle and loaded from Blob URLs, so there are no files to copy into `public/`.

## Install

The package lives on GitHub Packages. Add an `.npmrc` next to your `package.json`:

```ini
@jodybrewster:registry=https://npm.pkg.github.com
//npm.pkg.github.com/:_authToken=${NPM_TOKEN}
```

`NPM_TOKEN` is a GitHub token with `read:packages`. Then:

```bash
npm install @jodybrewster/gemini-live
```

To try a local build without publishing, pack it here and install the tarball by path:

```bash
npm -w @jodybrewster/gemini-live run build
cd packages/gemini-live-bundle && npm pack     # prints jodybrewster-gemini-live-<version>.tgz
# in the host
npm install /path/to/gemini-live-nextjs/packages/gemini-live-bundle/jodybrewster-gemini-live-<version>.tgz
```

To check jodybrewster.dev against your local build, run `scripts/site-check.sh` from the repo root (see Releasing).

## Server: token endpoint

Any runtime with the Web `Response` API works (Astro endpoints, Next route handlers, Workers).

```ts
// src/pages/api/voice/token.ts (Astro)
import { voiceTokenRouteFromEnv } from "@jodybrewster/gemini-live/server";

export const prerender = false;
const handler = voiceTokenRouteFromEnv({
  app: "my-site", // limiter counters: rl:voice:my-site
  constraints: () => ({ model: "gemini-3.8-live", config: { /* your locked Live config */ } }),
  sessionMs: 5 * 60_000,
  devOrigins: ["http://localhost:4321"],
});
export const POST = ({ request }) => handler(request);
export const OPTIONS = ({ request }) => handler(request);
```

`liveConnectConstraints` is passed straight to `authTokens.create`.
With it set, the whole Live setup is locked to the token's config, and whatever the browser sends in its own setup message (activity detection, tools, prompt) is ignored, so put the full config there.
Leave `lockAdditionalFields` unset unless you need it: Google rejects `lockAdditionalFields: []` with a 400 when the constrained config contains `tools`.

## Browser: a minimal voice button

```ts
import {
  GeminiLiveSession,
  createFunctionTool,
  type GeminiLiveConfig,
} from "@jodybrewster/gemini-live";

const session = new GeminiLiveSession({
  tokenEndpoint: "/api/voice/token",
  maxSessionMs: 5 * 60_000, // disconnects itself at the cap
  systemMessages: false, // keep "Ready!" / "[Microphone on]" out of the transcript
});

const openNote = createFunctionTool(
  "open_note",
  "Look up one of my notes by slug.",
  { slug: { type: "string" } },
  ["slug"],
  async ({ slug }) => {
    const res = await fetch(`/notes/${slug}.json`);
    return res.ok ? res.json() : null; // null: nothing to render in the chat
  },
);

const config: GeminiLiveConfig = {
  model: "gemini-3.8-live",
  systemInstructions: "You are a helpful assistant.",
  voiceName: "Puck",
  temperature: 1,
  googleGrounding: false,
  inputAudioTranscription: true,
  outputAudioTranscription: true,
  activityHandling: "ACTIVITY_HANDLING_UNSPECIFIED",
  automaticActivityDetection: {
    disabled: false,
    silence_duration_ms: 500,
    prefix_padding_ms: 500,
    end_of_speech_sensitivity: "END_SENSITIVITY_UNSPECIFIED",
    start_of_speech_sensitivity: "START_SENSITIVITY_UNSPECIFIED",
  },
  functions: [openNote],
};

session.subscribe(() => {
  const snap = session.getSnapshot();
  // Render from the snapshot: snap.connectionStatus, snap.messages,
  // snap.media.audio.isStreaming, snap.endsAt (countdown), snap.endReason.
});

button.addEventListener("click", async () => {
  if (session.getSnapshot().isConnected) {
    session.disconnect();
    return;
  }
  session.unlockAudio(); // synchronous, before any await
  try {
    await session.connect(config); // resolves on setup complete
    await session.toggleAudio(); // mic on
  } catch (error) {
    // connect() rejected: early close, socket error or 15 s timeout.
    // session.getSnapshot().lastError has the message.
  }
});
```

## API

`new GeminiLiveSession(options?)`

| Option | Default | |
|---|---|---|
| `tokenEndpoint` | `"/api/token"` | POST endpoint returning `{ token }`. |
| `maxSessionMs` | none | Caps a session, counted from setup complete. Ends with `endReason: "limit"`. |
| `connectTimeoutMs` | `15000` | How long `connect()` waits for setup complete. |
| `systemMessages` | `true` | Whether the session adds its own `system` messages to `messages`. |

Methods:

- `connect(config: GeminiLiveConfig): Promise<void>` - fetches a token, opens the socket and resolves once the server's setup complete arrives. Rejects if the socket closes or errors first, on timeout, or if `disconnect()` or another `connect()` supersedes it.
- `disconnect(): void` - ends the session with `endReason: "user"`.
- `unlockAudio(): void` - creates and resumes the playback AudioContext synchronously. Call it in the click handler before any `await`; iOS Safari leaves a context created later suspended.
- `toggleAudio(deviceId?: string): Promise<void>` - mic on/off.
- `toggleVideo(options?)`, `toggleScreen(options?)` - camera and screen share.
- `sendTextMessage(text: string): void`
- `subscribe(listener: () => void): () => void` and `getSnapshot(): SessionSnapshot` - a `useSyncExternalStore`-shaped store. The snapshot is a new object on every change.

`SessionSnapshot`:

```ts
{
  client: GeminiLiveAPI | null;
  isConnected: boolean;
  connectionStatus: "disconnected" | "connecting" | "connected" | "error";
  messages: ChatMessage[];
  audioPlayer: AudioPlayer | null;
  debugInfo: string;
  setupJson: string;
  endReason: "user" | "limit" | "goAway" | "closed" | "error" | null;
  endsAt: number | null; // epoch ms, set while maxSessionMs is running
  lastError: string | null;
  media: {
    audio: { isStreaming: boolean };
    video: { isStreaming: boolean; videoElement: HTMLVideoElement | null };
    screen: { isSharing: boolean; videoElement: HTMLVideoElement | null };
  };
}
```

Tools:

- `createFunctionTool(name, description, parameters, requiredParameters, fn, options?)` - `fn` may be async. `options.render` (default true) controls the chat message.
- Every local call in one toolCall batch is awaited, then answered with a single `toolResponse`. A rejected tool answers `{ error: message }` for its call only.
- `render: false` never adds a chat message. Otherwise an async tool's `tool-ui` message is added when it resolves, with the result as `toolData`; resolving to `null`/`undefined` adds nothing.

A Live API `goAway` from the server ends the session right away with `endReason: "goAway"`. Session resumption is not implemented.

## Size budgets and isolation

`npm run test:size` (part of `npm run check` and CI) builds fixture consumers that import each entry the way a host would and checks them gzipped with `size-limit` against ADR-0015's budgets: the chat core at most 15 KB, and voice at most 15 KB on top of it (today 3.0 KB and 6.9 KB). It also reads the browser build's esbuild metafile and fails if any server code (`src/server/`, the server core, `@google/genai`, the limiter stores) is reachable from a browser entry, or any voice code from `./core`. That check, not the build layout alone, keeps secret-reading code out of browser bundles.

## Releasing

jodybrewster.dev runs on this package, so a release is checked against the site before it ships.

1. Bump `version` in `package.json` in a PR. CI runs the site contract (`npm run test:contract`) and the `Site check` workflow, which runs the site's tests and type check against the packed bundle.
2. Before merging, run `scripts/site-check.sh` from the repo root. It packs the bundle, installs it into a clean clone of the site and runs the site's `npm test`, type check and `npm run build`, then prints the steps for a voice test in a browser. Pass a site branch or commit to check something other than `main`; a ref outside the site's `main` needs `--unmerged`, because the script runs the site's code with your privileges. That includes the site's dependencies, so `--unmerged` on a dependency bump runs code nobody has read; leave those to the CI site job.
3. Merge the PR, then tag the merged commit on `main` and push the tag:

   ```bash
   git tag gemini-live-v<version> <merged commit>
   git push origin gemini-live-v<version>
   ```

`.github/workflows/publish-gemini-live.yml` then refuses a tag that does not match the version or is not on `main`. It packs the bundle once and runs `npm run check`, the site contract and the site check (at the commit in `test/site-contract/site.json`) against that tarball. Only if all pass does its `publish` job, which checks nothing out and installs nothing, publish those exact bytes.

The tag checks catch mistakes, not a determined pusher: a tag runs the workflow file from the tagged commit. Someone with push access could edit the workflow on a branch and tag it. Worse, tagging any commit made before these checks landed runs the old workflow, which has no gate and publishes with install scripts running beside the publish token; `package.json` has said 0.1.1 since the bundle was added and 0.1.1 has never been published, so `git tag gemini-live-v0.1.1 <older main commit>` would publish an untested 0.1.1 without any edit. Until a tag ruleset limits who can push `gemini-live-v*` tags (`plans/foundation/later.md`), only tag commits that contain this workflow.

## Gotchas

- The worklets load from `blob:` URLs. A Content-Security-Policy has to allow `blob:` for scripts (or `worker-src`, depending on the browser).
- Import the `./server` entries only from server code (or build-time config, for `./server/headers`). No browser entry (root, `./core`, `./voice`) reaches `@google/genai` or any server code; `npm run test:size` proves it on every build.
- `connect()` rejects on failure. Catch it; with `systemMessages: false` nothing else tells the user.
- jodybrewster.dev runs on this package. `npm run test:contract` packs it and checks the tarball the way the site uses it (types, behavior, `publint`, `attw`); it is part of `npm run check` and CI. A change that fails it would break the site. See `test/site-contract/README.md`.
