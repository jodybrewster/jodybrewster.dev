# @jodybrewster/gemini-live

A framework-free Gemini Live client for the browser, plus a token handler for the server.
It is the monorepo's `@gemini-live/core`, `audio`, `session` and `video` packages bundled into one ESM package with no workspace dependencies.
No React, no router, no env reads.

- `@jodybrewster/gemini-live/core` - the text-only browser core, with no voice code: the message catalog, `disclosure()` and `fetchOrchestratorDisclosure`, the accessibility helpers (`createAnnouncer`, `createStreamAnnouncer`, `scheduleTimeWarnings`) and `readSseFrames`. `disclosure()` returns plain text: render it as text, never with `innerHTML` or `set:html`, since part of it can come from an orchestrator.
- `@jodybrewster/gemini-live/voice` - the voice session: `GeminiLiveSession`, the Gemini Live client, `createFunctionTool`, `AudioPlayer` and their types, plus `PLAYBACK_WORKLET_SOURCE` and `CAPTURE_WORKLET_SOURCE` for hosts whose security policy refuses `blob:` worklets (serve them from your origin and pass the URLs as the session's `audioWorklets`).
- `@jodybrewster/gemini-live` - the root re-exports `./voice` unchanged, so existing hosts keep working; new hosts should import `./core` or `./voice`.
- `@jodybrewster/gemini-live/server` - `createVoiceTokenHandler` and `voiceTokenRouteFromEnv`, which mint locked, short-lived Live API tokens behind an origin check and daily caps (see `@gemini-live/core`'s README). `createGeminiTokenHandler` was removed in 0.2.0 (it minted unlocked tokens for any caller).
- `@jodybrewster/gemini-live/server/limits` - the shared limiter (`createLimiter`, `createUpstashStore`, `limitStoreFromEnv`, `clientIp`, `limitResponse`, token budgets); see `@gemini-live/server-core`'s README.
- `@jodybrewster/gemini-live/server/switches` - kill switches (`createSwitches`, `enabledTools`); with no store they come from `SWITCH_*` env values alone.
- `@jodybrewster/gemini-live/server/audit` - the tamper-evident audit chain and its Upstash store (`chainKeyFromEnv`, `createUpstashAuditStore`, `verifyUpstashAudit`, `createLogAuditSink`, `createDenyThrottle`).
- `@jodybrewster/gemini-live/server/headers` - the security headers preset for a host's `astro.config` or header config (`astroCspDirectives`, `astroScriptResources`, `vercelHeaders`, `contentSecurityPolicy`, `staticSecurityHeaders`).
- `@jodybrewster/gemini-live/server/redact` - the redactor that removes personal details and secrets from text before it is stored or forwarded (`createDefaultRedactor`, `defaultRedactor`, `redactDeep`, `redactText`, `MAX_CHARS`, `REDACTION_VERSION` and the `Redactor` types); see `@gemini-live/server-core`'s README.

Peers are all optional and loaded only where used: `@google/genai` (`^1 || ^2`) by the token handler, `@upstash/redis` by the Upstash stores, `rate-limiter-flexible` by the memory limit store on first use, `libphonenumber-js` by `./server/redact` (its phone number rule). Install the ones your server code needs; the token handler uses your copy of `@google/genai`, never a nested one.

The audio worklets are embedded in the bundle and loaded from Blob URLs, so there are no files to copy into `public/`.

## License

The package is not open source.
It carries a narrow grant: a 90-day evaluation, and running the copy that Jody's sites send to a browser.
The terms are in [`LICENSE`](./LICENSE) and the reasoning in [ADR-0018](../../docs/adr/0018-ownership-and-license.md).
The package ships no sourcemaps.

## Install

Each version is a GitHub Release of this (private) repository, `gemini-live@<version>`, with the tarball and its `.sha256`.
Hosts vendor the tarball and install it by path; jodybrewster.dev does it with its `scripts/bundle-update.sh <version>`, which downloads the release with `gh`, refuses one that is not immutable, checks the sha256 and updates `package.json` and the lockfile:

```bash
gh release download gemini-live@<version> -R jodybrewster/gemini-live-nextjs -p '*.tgz' -p '*.sha256'
shasum -a 256 -c jodybrewster-gemini-live-<version>.tgz.sha256
npm install ./vendor/jodybrewster-gemini-live-<version>.tgz
```

To try a local build without publishing, pack it here and install the tarball by path:

```bash
npm -w @jodybrewster/gemini-live run build
cd packages/gemini-live-bundle && npm pack     # prints jodybrewster-gemini-live-<version>.tgz
# in the host
npm install /path/to/gemini-live-nextjs/packages/gemini-live-bundle/jodybrewster-gemini-live-<version>.tgz
```

To check jodybrewster.dev against your local build, run `scripts/site-check.sh` from the repo root (see Releasing).

## Server: token endpoint

Any runtime with the Web `Response` API works (Astro endpoints, Next route handlers, Workers).

```ts
// src/pages/api/voice/token.ts (Astro)
import { voiceTokenRouteFromEnv } from "@jodybrewster/gemini-live/server";

export const prerender = false;
const handler = voiceTokenRouteFromEnv({
  app: "my-site", // limiter counters: rl:voice:my-site
  constraints: () => ({ model: "gemini-3.8-live", config: { /* your locked Live config */ } }),
  sessionMs: 5 * 60_000,
  devOrigins: ["http://localhost:4321"],
});
export const POST = ({ request }) => handler(request);
export const OPTIONS = ({ request }) => handler(request);
```

`liveConnectConstraints` is passed straight to `authTokens.create`.
With it set, the whole Live setup is locked to the token's config, and whatever the browser sends in its own setup message (activity detection, tools, prompt) is ignored, so put the full config there.
Leave `lockAdditionalFields` unset unless you need it: Google rejects `lockAdditionalFields: []` with a 400 when the constrained config contains `tools`.

## Browser: a minimal voice button

```ts
import {
  GeminiLiveSession,
  createFunctionTool,
  type GeminiLiveConfig,
} from "@jodybrewster/gemini-live";

const session = new GeminiLiveSession({
  tokenEndpoint: "/api/voice/token",
  maxSessionMs: 5 * 60_000, // disconnects itself at the cap
  systemMessages: false, // keep "Ready!" / "[Microphone on]" out of the transcript
});

const openNote = createFunctionTool(
  "open_note",
  "Look up one of my notes by slug.",
  { slug: { type: "string" } },
  ["slug"],
  async ({ slug }) => {
    const res = await fetch(`/notes/${slug}.json`);
    return res.ok ? res.json() : null; // null: nothing to render in the chat
  },
);

const config: GeminiLiveConfig = {
  model: "gemini-3.8-live",
  systemInstructions: "You are a helpful assistant.",
  voiceName: "Puck",
  temperature: 1,
  googleGrounding: false,
  inputAudioTranscription: true,
  outputAudioTranscription: true,
  activityHandling: "ACTIVITY_HANDLING_UNSPECIFIED",
  automaticActivityDetection: {
    disabled: false,
    silence_duration_ms: 500,
    prefix_padding_ms: 500,
    end_of_speech_sensitivity: "END_SENSITIVITY_UNSPECIFIED",
    start_of_speech_sensitivity: "START_SENSITIVITY_UNSPECIFIED",
  },
  functions: [openNote],
};

session.subscribe(() => {
  const snap = session.getSnapshot();
  // Render from the snapshot: snap.connectionStatus, snap.messages,
  // snap.media.audio.isStreaming, snap.endsAt (countdown), snap.endReason.
});

button.addEventListener("click", async () => {
  if (session.getSnapshot().isConnected) {
    session.disconnect();
    return;
  }
  session.unlockAudio(); // synchronous, before any await
  try {
    await session.connect(config); // resolves on setup complete
    await session.toggleAudio(); // mic on
  } catch (error) {
    // connect() rejected: early close, socket error or 15 s timeout.
    // session.getSnapshot().lastError has the message.
  }
});
```

## API

`new GeminiLiveSession(options?)`

| Option | Default | |
|---|---|---|
| `tokenEndpoint` | `"/api/token"` | POST endpoint returning `{ token }`. |
| `maxSessionMs` | none | Caps a session, counted from setup complete. Ends with `endReason: "limit"`. |
| `connectTimeoutMs` | `15000` | How long `connect()` waits for setup complete. |
| `systemMessages` | `true` | Whether the session adds its own `system` messages to `messages`. |

Methods:

- `connect(config: GeminiLiveConfig): Promise<void>` - fetches a token, opens the socket and resolves once the server's setup complete arrives. Rejects if the socket closes or errors first, on timeout, or if `disconnect()` or another `connect()` supersedes it.
- `disconnect(): void` - ends the session with `endReason: "user"`.
- `unlockAudio(): void` - creates and resumes the playback AudioContext synchronously. Call it in the click handler before any `await`; iOS Safari leaves a context created later suspended.
- `toggleAudio(deviceId?: string): Promise<void>` - mic on/off.
- `toggleVideo(options?)`, `toggleScreen(options?)` - camera and screen share.
- `sendTextMessage(text: string): void`
- `subscribe(listener: () => void): () => void` and `getSnapshot(): SessionSnapshot` - a `useSyncExternalStore`-shaped store. The snapshot is a new object on every change.

`SessionSnapshot`:

```ts
{
  client: GeminiLiveAPI | null;
  isConnected: boolean;
  connectionStatus: "disconnected" | "connecting" | "connected" | "error";
  messages: ChatMessage[];
  audioPlayer: AudioPlayer | null;
  debugInfo: string;
  setupJson: string;
  endReason: "user" | "limit" | "goAway" | "closed" | "error" | null;
  endsAt: number | null; // epoch ms, set while maxSessionMs is running
  lastError: string | null;
  media: {
    audio: { isStreaming: boolean };
    video: { isStreaming: boolean; videoElement: HTMLVideoElement | null };
    screen: { isSharing: boolean; videoElement: HTMLVideoElement | null };
  };
}
```

Tools:

- `createFunctionTool(name, description, parameters, requiredParameters, fn, options?)` - `fn` may be async. `options.render` (default true) controls the chat message.
- Every local call in one toolCall batch is awaited, then answered with a single `toolResponse`. A rejected tool answers `{ error: message }` for its call only.
- `render: false` never adds a chat message. Otherwise an async tool's `tool-ui` message is added when it resolves, with the result as `toolData`; resolving to `null`/`undefined` adds nothing.

A Live API `goAway` from the server ends the session right away with `endReason: "goAway"`. Session resumption is not implemented.

## Size budgets and isolation

`npm run test:size` (part of `npm run check` and CI) builds fixture consumers that import each entry the way a host would and checks them gzipped with `size-limit` against ADR-0015's budgets: the chat core at most 15 KB, and voice at most 15 KB on top of it (today 3.0 KB and 6.9 KB). It also reads the browser build's esbuild metafile and fails if any server code (`src/server/`, the server core, `@google/genai`, the limiter stores) is reachable from a browser entry, or any voice code from `./core`. That check, not the build layout alone, keeps secret-reading code out of browser bundles.
The server build also writes `dist/metafile-server.json`, and the check fails when any third-party (`node_modules`) code is inlined into any entry, so the tarball carries no code under another licence.

## Releasing

jodybrewster.dev runs on this package, so a release is checked against the site before it ships (M2 2.1 and 2.2).

1. In the PR that changes what the bundle ships, add a changeset: `npx changeset`, pick patch, minor or major and write the changelog line (`npx changeset --empty` for a change that needs none). CI's `changeset` job fails a PR that changes the bundle's sources, or the sources of a workspace package it inlines, without one.
2. To cut a version, run `npm run release:version` on a branch of its own (a version PR may change nothing in the bundle but its version and changelog).
   It turns the pending changesets into the next version and its section of `CHANGELOG.md`, sets the same version in `package-lock.json` (that one field, no `npm install`) and tells you what to commit.
   Open a PR.
   The pre-push gate runs the site contract (ADR-0019).
   Run `scripts/site-check.sh` by hand: it runs the site's tests, type check, production build and browser specs (the security headers in Chromium, WebKit and Firefox and the accessibility specs, both with a mocked voice session) against the packed bundle.
3. Before merging, run `npm run release:check` on the version PR's branch, with the Node version in `.github/release-node-version` (it refuses another).
   It runs the local gate on that commit with every tier and fresh caches, which packs the bundle, then jodybrewster.dev's `main` against that tarball.
   It commits `packages/gemini-live-bundle/release-check.json`: the tarball's sha256, the tree checked (without the record), the site commit, the checks that ran, the Node version and the time.
   The file is not in the package, so it never changes the tarball.
4. Merge the PR.
   `.github/workflows/release.yml` runs on a push to `main` that changes the bundle's `package.json` or `release-check.json`, in about three minutes ([ADR-0021](../../docs/adr/0021-short-github-release.md)).
   - `plan` checks the version (greater than the last release, a changelog section, no pending changesets, no tag elsewhere) and the record: a closed schema, the same version, the Node pin and the merged tree.
     A version with no matching record fails.
   - `pack` builds once with the pinned Node.
   - `release` refuses unless the packed sha256 equals the record's, before it writes anything.
     It then creates the tag at the run's commit and the immutable GitHub Release `gemini-live@<version>` with the tarball and its `.sha256`, and reads them back.
     The notes say the hash was verified by the run and the checks were only reported by the local check.
   - If `main` moved after the check, the tree no longer matches: run `npm run release:check` again.

Releases in this repo are immutable: once published, a release's tarball and tag cannot change.
Immutability is not provenance, since anyone with a write token could create a release by hand.
So jodybrewster.dev's `bundle:update` vendors a release only if a successful `release` job of `release.yml` on `main` made it at the tag's commit, with the immutable tarball and `.sha256`.
The hash proves GitHub shipped the bytes that were checked locally.
It does not stop someone who can push to `main` and edit the record, so release trust equals the ability to land a commit on `main`; branch protection or an Environment with a required reviewer for the `release` job would narrow it (`plans/foundation/later.md`).
The deliberate step before visitors get a version is on the site: vendoring a release and merging that site PR, which deploys.
Nothing vendors a release automatically.

Old commits still carry the tag-triggered publish workflow this replaced, and pushing a `gemini-live-v*` tag at one would run it. Do not push such tags; a tag ruleset that forbids them is Jody's call (`plans/foundation/later.md`).

## Gotchas

- The worklets load from `blob:` URLs. A Content-Security-Policy has to allow `blob:` for scripts (or `worker-src`, depending on the browser).
- Import the `./server` entries only from server code (or build-time config, for `./server/headers`). No browser entry (root, `./core`, `./voice`) reaches `@google/genai` or any server code; `npm run test:size` proves it on every build.
- `connect()` rejects on failure. Catch it; with `systemMessages: false` nothing else tells the user.
- jodybrewster.dev runs on this package. `npm run test:contract` packs it and checks the tarball the way the site uses it (types, behavior, `publint`, `attw`); it is part of `npm run check` and CI. A change that fails it would break the site. See `test/site-contract/README.md`.
